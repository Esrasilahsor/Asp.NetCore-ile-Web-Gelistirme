﻿using Microsoft.AspNetCore.Mvc;
using WebHafta06.Models;

namespace WebHafta06.Controllers
{
    public class AnaController : Controller
    {
        public IActionResult Index()
        {
            List<Urun> listele = new List<Urun>()
            {
                new Urun{id=1,name="elma",fiyat=40},
                new Urun{id=2,name="armut",fiyat=55},
                new Urun{id=3,name="ayva",fiyat=100},
                new Urun{id=4,name="erik",fiyat=250}
            };

            return View();
        }
        public IActionResult Listele(Urun urun)
        {
            return View();
        }
        public IActionResult Ekle(Urun urun)
        {
            return View();
        }
        /*
        [HttpPost]
        public IActionResult Ekle(Urun urun)
        {
            return View();
        }
        */
        public IActionResult Sil(Urun urun)
        {
            return View();
        }
        public IActionResult Düzenle(Urun urun)
        {
            return View();
        }

        /*
        [HttpPost]
        public IActionResult Düzenle(Urun urun)
        {
            return View();
        }
        */
    }
}
