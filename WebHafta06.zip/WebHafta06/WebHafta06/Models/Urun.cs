﻿using System.Diagnostics;

namespace WebHafta06.Models
{
    public class Urun
    {
        public int id { get; set; }
        public string name { get; set; }
        public double fiyat { get; set; }

        public Urun()
        {

        }
        public Urun(int id, string name, double fiyat)
        {
            this.id = id;
            this.name = name;
            this.fiyat = fiyat;
        }
    }
}
