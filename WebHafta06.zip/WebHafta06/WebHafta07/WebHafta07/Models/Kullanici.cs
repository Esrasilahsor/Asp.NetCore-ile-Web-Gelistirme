﻿namespace WebHafta07.Models
{
    public class Kullanici
    {
        public int KullaniciId { get; set; }
        public string KullaniciAdi { get; set; }
        public string KullaniciMail { get; set; }
    }
}
