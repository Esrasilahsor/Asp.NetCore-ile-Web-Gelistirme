﻿namespace WebHafta07.Models
{
    public class Ara
    {
        public string Aranan { get; set; }
        public int Sayfa { get; set; }
    }
}
