﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor.Compilation;
using WebHafta07.Models;

namespace WebHafta07.Controllers
{
    public class AnaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult QueryStringAction(Ara a)
        {
            var queryStrings = Request.QueryString;
            foreach (var item in Request.Query.Keys)
            {
                var key = item;
                var value = Request.Query[key];
            }
            return View(a);
        }

        public IActionResult RouteValues(int id)
        {
            var routes = Request.RouteValues;
            foreach (var route in routes)
            {
                var key = route.Key;
                var value = route.Value;
            }
            return View();
        }

        public IActionResult HeaderValues()
        {
            var headers = Request.Headers;
            List<string> liste = new List<string>();
            foreach(var header in headers)
            {
                var key = header.Key;
                var value = header.Value;
            }
            return View();
        }

        public IActionResult TuppleVeri()
        {
            Kullanici kullanici = new Kullanici()
            {
                KullaniciId=1,
                KullaniciAdi="Esra",
                KullaniciMail="esra@gmail.com"
            };

            Urun urun = new Urun()
            {
                UrunId = 5,
                UrunAdi="Ekmek",
                UrunFiyat = 12.5
            };

            (Kullanici k, Urun u) tupple = (kullanici, urun);
            return View(tupple);
        }
        [HttpPost]
        public IActionResult TuppleVeri([Bind(Prefix ="Item1")] Kullanici k, [Bind(Prefix ="Item2")] Urun u)
        {
            return View();
        }
    }
}
