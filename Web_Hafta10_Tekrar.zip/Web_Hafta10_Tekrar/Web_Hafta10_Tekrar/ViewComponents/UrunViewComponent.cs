﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;
using Web_Hafta10_Tekrar.Models;

namespace Web_Hafta10_Tekrar.ViewComponents
{
    public class UrunViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            List<Urun> liste = new List<Urun>()
            {
                new Urun {UrunId=1,UrunAd="test",UrunAciklama="ViewComponent",UrunFiyat=1}
            };
            return View(liste);
        }

    }
}
