var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

app.UseStaticFiles(new StaticFileOptions
{
    RequestPath="/wwwroot",
});
app.MapControllerRoute("Yeter_Art�k", "{controller=Home}/{action=Index}/{id?}");
app.MapDefaultControllerRoute();
app.Run();
