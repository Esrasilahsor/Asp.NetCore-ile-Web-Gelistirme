﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Hafta10_Tekrar.Controllers
{
    public class YonetimController : Controller
    {
        [Route("Yeter_Artık")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
