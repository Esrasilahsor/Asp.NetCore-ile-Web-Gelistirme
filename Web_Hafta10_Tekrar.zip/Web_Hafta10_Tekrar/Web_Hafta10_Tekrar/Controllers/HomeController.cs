﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta10_Tekrar.Models;

namespace Web_Hafta10_Tekrar.Controllers
{
    public class HomeController : Controller
    {

        static List<Urun> liste = new List<Urun>();
        public HomeController()
        {
            if (!liste.Any())
            {
                liste.Add(new Urun
                {
                    UrunId = 1,
                    UrunAd = "Test",
                    UrunAciklama = "Test edildi",
                    UrunFiyat = 10
                });
            }
        }

        public IActionResult Index()
        {
            return View(liste);
        }
        public IActionResult Ekle()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Ekle(Urun urun)
        {
            if (urun != null)
            {
                liste.Add(urun);
                return RedirectToAction("Index");
            }
            else
            {
                return View(liste);
            }
 
        }
        public IActionResult Hakkimizda()
        {
            return View();
        }
        public IActionResult Blog()
        {
            return View();
        }
        public IActionResult Iletisim()
        {
            return View();
        }
        public IActionResult Personel()
        {
            return View();
        }
    }
}
