﻿namespace Web_Hafta10_Tekrar.Models
{
    public class Urun
    {
        public int UrunId { get; set; }
        public string UrunAd { get; set; }
        public string UrunAciklama { get; set; }
        public double UrunFiyat { get; set; }

    }
}
