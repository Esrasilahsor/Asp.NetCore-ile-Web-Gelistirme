﻿namespace Web_Hafta10_Layout.Models
{
    public class Kullanici
    {
    }
}
