using Microsoft.AspNetCore.Authentication;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

var app = builder.Build();

app.UseStaticFiles(new StaticFileOptions()
{
    RequestPath="/wwwroot",
}
);
app.MapControllerRoute("main","{controller=Ana}/{action=Index}/{id?}");

app.Run();
