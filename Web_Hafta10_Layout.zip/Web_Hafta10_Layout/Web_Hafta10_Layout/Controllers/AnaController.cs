﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Hafta10_Layout.Controllers
{
    public class AnaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Sayfa1()
        {
            return View();
        }
        public IActionResult Sayfa2()
        {
            return View();
        }
    }
}
