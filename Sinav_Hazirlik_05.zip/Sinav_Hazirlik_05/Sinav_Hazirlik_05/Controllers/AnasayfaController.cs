﻿using Microsoft.AspNetCore.Mvc;

namespace Sinav_Hazirlik_05.Controllers
{
    public class AnasayfaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
