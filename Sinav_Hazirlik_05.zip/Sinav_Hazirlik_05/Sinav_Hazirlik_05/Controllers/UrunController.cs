﻿using Microsoft.AspNetCore.Mvc;
using Sinav_Hazirlik_05.Models;

namespace Sinav_Hazirlik_05.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult Urun()
        {
            List<Urun> liste = new List<Urun>
            {
                new Urun(1,"kalem","kurşun kalem",50.5),
                new Urun(2,"defter","80 yaprak",100.5),
                new Urun(3,"silgi","yumuşak",30.5),
                new Urun(4,"kalemtraş","kapalı kutu",20.5)
            };
            
            return View(liste);
        }

        // Kullanıcı formu ilk açtığında boş görünmesi için
        [HttpGet]
        public IActionResult Ekle() {

            Urun bosmodel = new Urun();
            return View(bosmodel);
        }

        [HttpPost]
        public IActionResult Ekle(int id, string adi, string aciklama,double fiyat)
        {
            Urun urun = new Urun();
            return View();
        }
    }
}
