﻿namespace Sinav_Hazirlik_05.Models
{
    public class Urun
    {
        public int id { get; set; }
        public string ad { get; set; }
        public string aciklama { get; set; }
        public double fiyat { get; set; }

        public Urun()
        {

        }
        public Urun(int id,string ad, string aciklama,double fiyat)
        {
            this.id = id;
            this.ad = ad;
            this.aciklama = aciklama;
            this.fiyat = fiyat;
        }

    }
}
