﻿using Microsoft.AspNetCore.Identity;
using Web_Hafta12_Tekrar.Middlewares;

namespace Web_Hafta12_Tekrar.Extensions
{
    static public class Extension
    {
        public static IApplicationBuilder UseBanu(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<BanuMiddleware>();
        }
    }
}
