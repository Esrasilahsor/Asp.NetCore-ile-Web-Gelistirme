using Web_Hafta12_Tekrar.Extensions;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

var app = builder.Build();

app.MapDefaultControllerRoute();
app.Use(async (context, next) =>
{
    Console.WriteLine("Web s�nav ba�lad�...");
    await next.Invoke();
    Console.WriteLine("Web s�nav bitti...");
});

app.Use(async (context, next) =>
{
    Console.WriteLine("Middleware 2 ba�lad�...");
    await next.Invoke();
    Console.WriteLine("Middleware 2 bitti...");
});

app.UseBanu();


app.Run(async (context) =>
{
    Console.WriteLine("Run middleware �al���yor");
});

app.Run();
