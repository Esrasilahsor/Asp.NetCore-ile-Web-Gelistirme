﻿namespace Web_Hafta12_Tekrar.Middlewares
{
    public class BanuMiddleware
    {
        RequestDelegate _next;
       public BanuMiddleware(RequestDelegate next)
       {
            this._next = next;
       }
        public async Task Invoke(HttpContext context)
        {
            Console.WriteLine("Banu middleware başladı...");
            await _next.Invoke(context);
            Console.WriteLine("Banu middleware bitti...");
        }

    }
}
