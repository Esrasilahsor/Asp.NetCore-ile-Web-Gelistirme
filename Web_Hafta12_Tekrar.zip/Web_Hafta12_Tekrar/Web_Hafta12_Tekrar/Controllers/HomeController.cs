﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Hafta12_Tekrar.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
