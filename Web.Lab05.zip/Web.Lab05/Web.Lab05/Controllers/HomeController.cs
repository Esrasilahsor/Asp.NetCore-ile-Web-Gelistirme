using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Web.Lab05.Models;

namespace Web.Lab05.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
