﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Web.Lab05.Models;


namespace Web.Lab05.Controllers
{
    public class OgrenciController : Controller
    {
        public IActionResult Index()
        {
            var ogrenciler = new List<Ogrenci>
            {
                new Ogrenci{OgrId=123,OgrAd="Ahmet",Bolum="Yazılım Müh."},
                new Ogrenci{OgrId=124,OgrAd="Ayşe",Bolum="Yazılım Müh."},
                new Ogrenci{OgrId=125,OgrAd="Mehmet",Bolum="Yazılım Müh."}
            };

            ViewBag.data1 = ogrenciler;
            ViewData["data2"] = ogrenciler;
            TempData["data3"] = ogrenciler;

            return View();
        }

        public IActionResult Index2() 
        {
            ViewBag.x = 5;
            ViewData["x"] = 5;
            TempData["x"] = 5;
            return RedirectToAction("Index3");
        }

        public IActionResult Index3()
        {
            var v1 = ViewBag.x;
            var v2 = ViewData["x"];
            var v3 = TempData["x"];
            return View();
        }
    }
}
