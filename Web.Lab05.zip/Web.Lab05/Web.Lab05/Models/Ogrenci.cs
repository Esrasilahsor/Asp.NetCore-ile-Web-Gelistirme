﻿namespace Web.Lab05.Models
{
    public class Ogrenci
    {
        public int OgrId { get; set; }
        public string OgrAd { get; set; }
        public string Bolum { get; set; }
    }
}
