﻿namespace Sinav_Hazirlik_04.Models
{
    public class Kullanici
    {
        public int id { get; set; }
        public string name { get; set; }
        public string mail { get; set; }
        public string password { get; set; }


    }
}
