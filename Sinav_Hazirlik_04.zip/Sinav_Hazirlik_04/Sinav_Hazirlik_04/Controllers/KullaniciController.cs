﻿using Microsoft.AspNetCore.Mvc;
using Sinav_Hazirlik_04.Models;
using System.Text.Json;

namespace Sinav_Hazirlik_04.Controllers
{
    public class KullaniciController : Controller
    {
        public IActionResult KullaniciViewBag()
        {
            Kullanici kul = new Kullanici();

            kul.id = 2;
            kul.name = "Ayşe";
            kul.mail = "ayse@gmail.com";
            kul.password = "12345";

            ViewBag.kullanici = kul;

            return View();
        }
        public IActionResult KullaniciViewData()
        {
            Kullanici kul = new Kullanici();

            kul.id = 3;
            kul.name = "Merve";
            kul.mail = "merve@gmail.com";
            kul.password = "12345";

            ViewData["kullanici"] = kul;

            return View();
        }
        public IActionResult KullaniciTempData()
        {
            Kullanici kul = new Kullanici();

            kul.id = 4;
            kul.name = "Cennet";
            kul.mail = "cennet@gmail.com";
            kul.password = "12345";

            TempData["kullanici"] = kul;

            return View();
        }
        public IActionResult Listele() {

            List<Kullanici> liste = new List<Kullanici>()
            {
                new Kullanici {id=1,name="Esra",mail="esra@gmail.com",password="1234"},
                new Kullanici {id=2,name="Ayşe",mail="ayse@gmail.com",password="5678"},
                new Kullanici {id=3,name="Merve",mail="merve@gmail.com",password="9012"},
                new Kullanici {id=4,name="Cennet",mail="cennet@gmail.com",password="3456"}
            };

            ViewBag.liste = liste;
            ViewData["liste"]=liste;

            string jsonliste = JsonSerializer.Serialize(liste);

            TempData["liste"]= jsonliste;

            return View(liste); 
        }

    }
}
