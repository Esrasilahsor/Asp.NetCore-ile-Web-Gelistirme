﻿using Microsoft.AspNetCore.Mvc;
using Sinav_Hazirlik_04.Models;

namespace Sinav_Hazirlik_04.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            Kullanici kul = new Kullanici();

            kul.id = 1;
            kul.name = "Esra";
            kul.mail = "esra@gmail.com";
            kul.password = "12345";
           

            return View();
        }

        
    }
}
