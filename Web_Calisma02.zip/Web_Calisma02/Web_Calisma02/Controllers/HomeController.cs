﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Calisma02.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            int a, b;
            a = 55;
            b = 20;
            var sonuc = a + b;
            return View(sonuc);
        }
        public IActionResult BanuYm()
        {
            return View();
        }
    }
}
