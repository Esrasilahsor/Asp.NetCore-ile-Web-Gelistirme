﻿namespace Sınav_Hazirlik_01.Models
{
    public class Urun
    {
        public int id { get; set; }
        public string isim { get; set; }
        public int fiyat { get; set; }
    }
}
