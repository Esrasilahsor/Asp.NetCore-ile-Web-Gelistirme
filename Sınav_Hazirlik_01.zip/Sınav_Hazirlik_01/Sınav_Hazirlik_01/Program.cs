var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

var app = builder.Build();

app.MapControllerRoute("ana-route", "{controller=Home}/{action=Index}/{id?}");

app.Run();
