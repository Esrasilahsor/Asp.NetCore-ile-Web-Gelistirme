﻿using Microsoft.AspNetCore.Mvc;
using Sınav_Hazirlik_01.Models;

namespace Sınav_Hazirlik_01.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            int a, b;
            a = 1;
            b = 2;
            int sonuc = a + b;
            return View(sonuc);
        }
    }
}
