﻿using Microsoft.AspNetCore.Mvc;
using Web_Calisma03.Models;

namespace Web_Calisma03.Controllers
{
    public class ResultController : Controller
    {
        public ViewResult ViewResultSayfa()
        {
            return View();
        }

        public PartialViewResult PartialSayfa()
        {
           return PartialView();
        }
        public JsonResult JsonSayfa()
        {
            Urun urun = new Urun()
            {
                Id = 1,
                UrunAdi = "Monitor",
                UrunFiyati = 19999.99
            };
            return Json(urun);
        }
        public EmptyResult EmptySayfa()
        {
            return new EmptyResult();
        }

        [NonAction]
        public ContentResult ContentResult()
        {
            return Content("jdj<d");
        }

        public ActionResult Index1(int id)
        {
            switch (id)
            {
                case 1:
                    return View();
                case 2:
                    return Json("djdjdj");
                case 3:
                    return new EmptyResult();
                case 4:
                    return Content("jsdjjjd");
                case 5:
                    return PartialView();
                case 6:
                    return ViewComponent("");
                default:    
                    return View();
            }
            
        }
    }
}
