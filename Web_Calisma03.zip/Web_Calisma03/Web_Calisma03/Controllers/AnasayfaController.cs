﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Calisma03.Controllers
{
    [NonController]
    public class AnasayfaController : Controller
    {
        public IActionResult Index()
        {
            int a=10; int b=2;
            int sonuc = a / b;
            return View(sonuc);
        }
    }
}
