﻿namespace Web_Hafta13_Dependency_Injection.Services
{
    public class TextLog:ILog
    {
        public void Log()
        {
            Console.WriteLine("TextLog loglama işlemi gerçekleştirildi...");        
        }
    }
}
