﻿namespace Web_Hafta13_Dependency_Injection.Services
{
    public interface ILog
    {
        public void Log();
    }
}
