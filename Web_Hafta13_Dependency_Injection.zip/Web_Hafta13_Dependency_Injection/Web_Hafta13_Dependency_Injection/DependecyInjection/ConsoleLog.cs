﻿namespace Web_Hafta13_Dependency_Injection.Services
{
    public class ConsoleLog:ILog
    {
        public ConsoleLog(int a)
        {
        }
        public void Log()
        {
            Console.WriteLine("Console loglama işlemi gerçekleştirildi...");
        }
    }
}
