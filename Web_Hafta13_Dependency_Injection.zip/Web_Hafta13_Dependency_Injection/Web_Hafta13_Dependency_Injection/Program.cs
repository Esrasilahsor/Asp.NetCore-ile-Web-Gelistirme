using Web_Hafta13_Dependency_Injection.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

builder.Services.AddTransient<ILog,ConsoleLog>(p => new ConsoleLog(3));

var app = builder.Build();

app.MapControllerRoute("main","{controller=Home}/{action=Index}/{id?}");


app.Run();
