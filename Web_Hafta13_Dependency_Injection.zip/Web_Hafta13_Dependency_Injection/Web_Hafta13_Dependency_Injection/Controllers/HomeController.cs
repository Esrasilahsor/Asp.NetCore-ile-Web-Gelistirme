using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Web_Hafta13_Dependency_Injection.Models;
using Web_Hafta13_Dependency_Injection.Services;

namespace Web_Hafta13_Dependency_Injection.Controllers
{
    public class HomeController : Controller
    {
        ILog _log;
        public HomeController(ILog log)
        {
            this._log = log;
        }
        public IActionResult Index()
        {
            _log.Log();
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        
    }
}
