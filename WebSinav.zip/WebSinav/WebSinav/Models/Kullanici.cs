﻿namespace WebSinav.Models
{
    public class Kullanici
    {
        public int KullaniciId { get; set; }
        public string KullaniciAd{ get; set; }
        public string KullaniciEmail { get; set; }
        public string KullaniciTel { get; set; }

        public Kullanici()
        {

        }
         public Kullanici(int KullaniciId, string KullaniciAd, string KullaniciEmail, string KullaniciTel)
        {
            this.KullaniciId = KullaniciId;
            this.KullaniciAd= KullaniciAd;
            this.KullaniciEmail = KullaniciEmail;
            this.KullaniciTel= KullaniciTel;
        }
    }
}
