﻿using Microsoft.AspNetCore.Mvc;
using WebSinav.Models;

namespace WebSinav.Controllers
{
    public class AnasayfaController : Controller
    {
        private static List<Kullanici> _kullaniciListesi = new List<Kullanici>();
        // GET: Home
        public ActionResult Index()
        {
            return View(_kullaniciListesi);
        }

        // GET: KullaniciEkle
        public ActionResult KullaniciEkle()
        {
            return View();
        }

        // POST: KullaniciEkle
        [HttpPost]
        public ActionResult KullaniciEkle(Kullanici model)
        {
            _kullaniciListesi.Add(model);
                
            return View(model);
        }
    }
}
