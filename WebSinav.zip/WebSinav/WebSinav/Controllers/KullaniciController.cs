﻿using Microsoft.AspNetCore.Mvc;
using WebSinav.Models;

namespace WebSinav.Controllers
{
    public class KullaniciController : Controller
    {
        public IActionResult Listele()
        {
            List<Kullanici> liste = new List<Kullanici>()
        {
            new Kullanici { KullaniciId = 1, KullaniciAd="Abdullah ELEN" },
            new Kullanici { KullaniciId = 2, KullaniciAd="Aykut DIKER" },
            new Kullanici { KullaniciId = 3, KullaniciAd="Buket TOPTAŞ" },
            new Kullanici { KullaniciId = 4, KullaniciAd="Emrah DÖNMEZ" },
            new Kullanici { KullaniciId = 5, KullaniciAd="Fahrettin Burak DEMİR" },
            new Kullanici { KullaniciId = 6, KullaniciAd="İbrahim ARPACI" },
            new Kullanici { KullaniciId = 7, KullaniciAd="Serhat KILIÇARSLAN" },
            new Kullanici { KullaniciId = 8, KullaniciAd="Süleyman Gökhan TAŞKIN" },
            new Kullanici { KullaniciId = 9, KullaniciAd="\"Ömer ASLAN", KullaniciEmail="gokhan@handfirma.edu.tr", KullaniciTel="0266 606 35 50" }

        };
            return View(liste);
        }
        public IActionResult Detay(int id)
        {
            List<Kullanici> liste = new List<Kullanici>()
        {
            new Kullanici { KullaniciId = 1, KullaniciAd = "Abdullah ELEN" },
            new Kullanici { KullaniciId = 2, KullaniciAd = "Aykut DIKER" },
            new Kullanici { KullaniciId = 3, KullaniciAd = "Buket TOPTAŞ" },
            new Kullanici { KullaniciId = 4, KullaniciAd = "Emrah DÖNMEZ" },
            new Kullanici { KullaniciId = 5, KullaniciAd = "Fahrettin Burak DEMİR" },
            new Kullanici { KullaniciId = 6, KullaniciAd = "İbrahim ARPACI" },
            new Kullanici { KullaniciId = 7, KullaniciAd = "Serhat KILIÇARSLAN" , KullaniciEmail = "gokhan@handfirma.edu.tr", KullaniciTel = "0266 606 35 50"},
            new Kullanici { KullaniciId = 8, KullaniciAd = "Süleyman Gökhan TAŞKIN", KullaniciEmail = "gokhan@handfirma.edu.tr", KullaniciTel = "0266 606 35 50" },
            new Kullanici { KullaniciId = 9, KullaniciAd = "Ömer ASLAN", KullaniciEmail = "gokhan@handfirma.edu.tr", KullaniciTel = "0266 606 35 50" }

        };

        var kullanici = liste.FirstOrDefault(x => x.KullaniciId == id);

            return View(kullanici);
        }

    }
}
