﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta13_Tekrar.DependecyInjection;
using Web_Hafta13_Tekrar.Models;

namespace Web_Hafta13_Tekrar.Controllers
{
    public class HomeController : Controller
    {
        public ILog _log;
        public HomeController(ILog log)
        {
            this._log = log;
        }
        public IActionResult Index()
        {
            //ITopluTasima otobüs = new Otobüs();
            //ITopluTasima metro = new Metro();
            //ITopluTasima metrobus = new Metrobus();

            //otobüs.BiletBas();
            //metro.BiletBas();
            //metrobus.BiletBas();
            _log.LogYaz();
            return View();
        }
    }  
}
