﻿namespace Web_Hafta13_Tekrar.DependecyInjection
{
    public class Metro : ITopluTasima
    {
        public void BiletBas()
        {
            Console.WriteLine("Bilet basıldı..");
        }
    }
}
