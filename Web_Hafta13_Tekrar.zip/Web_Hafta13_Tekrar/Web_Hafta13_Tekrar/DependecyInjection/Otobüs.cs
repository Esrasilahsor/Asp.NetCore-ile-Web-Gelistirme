﻿namespace Web_Hafta13_Tekrar.DependecyInjection
{
    public class Otobüs:ITopluTasima
    {
        public void BiletBas()
        {
            Console.WriteLine("Bilet basıldı..");
        }
    }
}
