﻿namespace Web_Hafta13_Tekrar.DependecyInjection
{
    public interface ITopluTasima
    {
        void BiletBas();
    }
}
