﻿namespace Web_Hafta13_Tekrar.DependecyInjection
{
    public class Metrobus:ITopluTasima
    {
        public void BiletBas()
        {
            Console.WriteLine("Bilet basıldı..");
        }
    }
}
