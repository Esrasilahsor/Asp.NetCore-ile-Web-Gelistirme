﻿namespace Web_Hafta13_Tekrar.Models
{
    public interface ILog
    {
        public void LogYaz();
    }
}
