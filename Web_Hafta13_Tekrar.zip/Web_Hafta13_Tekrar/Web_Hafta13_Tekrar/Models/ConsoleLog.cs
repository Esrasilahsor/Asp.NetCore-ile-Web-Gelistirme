﻿namespace Web_Hafta13_Tekrar.Models
{
    public class ConsoleLog : ILog
    {
        public int classId {  get; set; }
        public ConsoleLog()
        {
            Random rnd = new Random();
            classId=rnd.Next(1, 100);
        }
        public void LogYaz()
        {
            Console.WriteLine($"ConsoleEkranına Log yazıldı .ClassID = {classId}");
        }
    }
}
