﻿namespace Web_Hafta13_Tekrar.Models
{
    public class TextLog
    {
        public void LogYaz()
        {
            Console.WriteLine($"text Ekranına Log yazıldı.");
        }
    }
}
