﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Hafta11_ViewComponent_Örnek.Controllers
{
    [Route("Banu-Yonetim")]
    public class YönetimController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
