using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Web_Hafta11_ViewComponent_Örnek.Models;

namespace Web_Hafta11_ViewComponent_Örnek.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

    }
}
