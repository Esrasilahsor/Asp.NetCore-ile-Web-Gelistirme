﻿using Web_Hafta11_ViewComponent_Örnek.Models;
using Microsoft.AspNetCore.Mvc;

namespace Web_Hafta11_ViewComponent_Örnek.ViewComponents
{
    public class KullaniciViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            List<Kullanici> liste = new List<Kullanici>
            {
                new Kullanici{ KullaniciId=1, KullaniciAd="Esra",KullaniciSoyad="Silahşor",KullaniciEmail="esrasilahsor16@gmail.com" }
            };
            return View(liste);
        }
    }
}
