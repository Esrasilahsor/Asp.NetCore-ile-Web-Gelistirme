﻿namespace Web_Hafta11_ViewComponent_Örnek.Models
{
    public class Kullanici
    {
        public int KullaniciId { get; set; }
        public string KullaniciAd { get; set; }
        public string KullaniciSoyad { get; set; }
        public string KullaniciEmail { get; set; }
        public Kullanici()
        {

        }
    }
}
