﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class OgrenciController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }

        public PartialViewResult Index2()
        {
            return PartialView();
        }

        public JsonResult Index3()
        {
            var ogrenci = new
            {
                ad = "Esra",
                no = "2211505030",
                bolum = "Yazılım Mühendisliği"

            };
            return Json(ogrenci);
        }

        public ContentResult Index4()
        {
            return Content("Merhaba Dünya!");
        }

        public ActionResult Index5() 
        {
            var ogrenci = new
            {
                ad = "Esra",
                no = "2211505030",
                bolum = "Yazılım Mühendisliği"

            };
            return Json(ogrenci);
        }

        public ActionResult Index6()
        {

            return Content("Merhaba Dünya!");
        }

        // Uygulamada hangi türün döneceği kesinse ActionResult kullanılabilir.
        // Her türlü senaryo ve veri türüne uyum sağlayabilir.

    }
}
