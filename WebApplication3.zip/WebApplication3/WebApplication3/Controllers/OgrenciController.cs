﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class OgrenciController : Controller
    {
        public IActionResult Index()
        {
            var ogrenciler = new List<Ogrenci>
            {
                new Ogrenci{OgrId=123,OgrAd="Ahmet",Bolum="Yazılım Müh."},
                new Ogrenci{OgrId=124,OgrAd="Ayşe",Bolum="Yazılım Müh."},
                new Ogrenci{OgrId=125,OgrAd="Mehmet",Bolum="Yazılım Müh."}
            };

            //string jsonliste=JsonSerializer.Serialize(ogrenciler);

            ViewBag.data1 = ogrenciler;
            //ViewData["data2"] = ogrenciler;
            //TempData["data3"] = jsonliste;

            return View();
        }
    }
}
