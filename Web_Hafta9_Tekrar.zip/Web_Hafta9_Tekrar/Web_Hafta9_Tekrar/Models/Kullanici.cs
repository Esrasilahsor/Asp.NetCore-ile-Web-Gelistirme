﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Web_Hafta9_Tekrar.Models
{
    //[ModelMetadataType(typeof(KullaniciMetadata))]
    public class Kullanici
    {
        public int KullaniciId { get; set; }
        public string KullaniciAd { get; set; }
        public string KullaniciSoyad { get; set; }
        public string KullaniciEmail { get; set; }

        public Kullanici()
        {

        }
        public Kullanici(int id,string ad, string soyad, string email)
        {
            KullaniciId = id;
            KullaniciAd = ad;
            KullaniciSoyad = soyad;
            KullaniciEmail= email;
        }
    }
}
