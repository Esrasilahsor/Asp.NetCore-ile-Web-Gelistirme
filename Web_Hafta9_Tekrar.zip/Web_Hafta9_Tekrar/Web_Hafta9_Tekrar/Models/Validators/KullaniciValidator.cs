﻿using System.ComponentModel.DataAnnotations;
using FluentValidation;
using Web_Hafta9_Tekrar.Models;

namespace Web_Hafta9_Tekrar.Models.Validators
{
    public class KullaniciValidator : AbstractValidator<Kullanici>
    {
        public KullaniciValidator()
        {
            RuleFor(a => a.KullaniciId)
                .NotEmpty().WithMessage("Kullanici id boş olamaz")
                .NotNull().WithMessage("Kullanici id boş olamaz");
            RuleFor(a => a.KullaniciAd)
                .NotEmpty().WithMessage("Kullanici id boş olamaz")
                .NotNull().WithMessage("Kullanici id boş olamaz")
                .MinimumLength(5).WithMessage("Kullanıcı adı en az 5 karakter olabilir")
                .MaximumLength(20).WithMessage("Kullanıcı adı en fazla 20 karakter olabilir");
            RuleFor(a => a.KullaniciSoyad)
                .NotEmpty().WithMessage("Kullanici id boş olamaz")
                .NotNull().WithMessage("Kullanici id boş olamaz")
                .MinimumLength(5).WithMessage("Kullanıcı adı en az 5 karakter olabilir")
                .MaximumLength(20).WithMessage("Kullanıcı adı en fazla 20 karakter olabilir");
            RuleFor(a => a.KullaniciEmail)
                .NotEmpty().WithMessage("Kullanici id boş olamaz")
                .NotNull().WithMessage("Kullanici id boş olamaz")
                .EmailAddress().WithMessage("Geçerli bir mail giriniz");
        }
    }
}
