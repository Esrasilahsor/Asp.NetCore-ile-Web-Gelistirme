﻿using System.ComponentModel.DataAnnotations;

namespace Web_Hafta9_Tekrar.Models
{
    public class KullaniciMetadata
    {
    //    [Required(ErrorMessage = "Lütfen kullanıcı ad giriniz")]
    //    [Length(minimumLength: 2, maximumLength: 15, ErrorMessage = "lütfen minimum 2 maksimum 15 karakter giriniz")]
    //    public string KullaniciAd { get; set; }
    //    [Required(ErrorMessage = "Lütfen kullanıcı soyad giriniz")]
    //    [Length(minimumLength: 2, maximumLength: 15, ErrorMessage = "lütfen minimum 2 maksimum 15 karakter giriniz")]
    //    public string KullaniciSoyad { get; set; }
    //    [Required(ErrorMessage = "Lütfen kullanıcı email giriniz")]
    //    [EmailAddress(ErrorMessage = "Lütfen geçerli bir email adresi giriniz")]
    //    public string KullaniciEmail { get; set; }

    }
}
