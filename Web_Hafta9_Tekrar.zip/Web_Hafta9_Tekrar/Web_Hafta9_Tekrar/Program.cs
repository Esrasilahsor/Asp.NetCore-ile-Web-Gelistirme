using FluentValidation;
using FluentValidation.AspNetCore;
using Web_Hafta9_Tekrar.Models.Validators;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
//builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<KullaniciValidator>();
builder.Services.AddFluentValidationClientsideAdapters();



var app = builder.Build();
app.MapDefaultControllerRoute();
app.UseStaticFiles();

app.Run();