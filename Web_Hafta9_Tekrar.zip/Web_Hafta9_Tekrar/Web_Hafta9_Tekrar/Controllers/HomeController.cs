﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Web_Hafta9_Tekrar.Models;

namespace Web_Hafta9_Tekrar.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Ekle()
        {
            ViewBag.Message = "";
            return View();
        }
        [HttpPost]
        public IActionResult Ekle(Kullanici kullanici)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = "Kullanıcı eklendi";
            }
            else
            {
                ViewBag.Message = "Kullanıcı eklenirken hata oluştu";
            }
            return View(kullanici);
        }
    }
}
