using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Web_Hafta13_HocaninÖrnek.Models;

namespace Web_Hafta13_HocaninÖrnek.Controllers
{
    public class HomeController : Controller
    {
        ILog _log;
        public HomeController(ILog log)
        {
            _log = log;
        }
        public IActionResult Index()
        {
            _log.LogYaz();
            return View();
        }
        public IActionResult Detay()
        {
            _log.LogYaz();
            return View();
        }

    }
}
