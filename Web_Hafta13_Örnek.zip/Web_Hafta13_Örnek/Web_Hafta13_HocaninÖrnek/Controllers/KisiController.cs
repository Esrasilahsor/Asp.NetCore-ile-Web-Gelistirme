﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta13_HocaninÖrnek.Models;

namespace Web_Hafta13_HocaninÖrnek.Controllers
{
    public class KisiController : Controller
    {
        public ILog log {  get; set; }
        public KisiController(ILog log)
        {
            this.log = log;
        }
        public IActionResult Index()
        {
            log.LogYaz();
            return View();
        }
    }
}
