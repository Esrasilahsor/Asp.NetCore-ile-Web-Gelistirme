﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta13_HocaninÖrnek.Models;

namespace Web_Hafta13_HocaninÖrnek.ViewComponents
{
    public class BanuViewComponent : ViewComponent
    {
        ILog log;
        public BanuViewComponent(ILog log)
        {
            this.log = log;
        }

        public IViewComponentResult Invoke()
        {
            log.LogYaz();
            return View();
        }

    }
}
