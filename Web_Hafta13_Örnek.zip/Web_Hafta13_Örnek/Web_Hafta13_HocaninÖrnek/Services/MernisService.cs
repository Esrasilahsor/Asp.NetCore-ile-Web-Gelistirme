﻿namespace Web_Hafta13_HocaninÖrnek.Services
{
    public class MernisService
    {
        public MernisService()
        {
            throw new Exception("Servise şu an ulaşılamıyor.");
        }
        public string KisiGetir(string Tc)
        {
            return "Esra Silahşor";
        }
    }
}
