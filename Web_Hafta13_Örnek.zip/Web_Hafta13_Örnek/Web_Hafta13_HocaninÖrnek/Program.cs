using Web_Hafta13_Hocanin�rnek.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

builder.Services.AddScoped<ILog, ConsoleLog>();

var app = builder.Build();

app.MapControllerRoute("main", "{controller=Home}/{action=Index}/{id?}");


app.Run();
