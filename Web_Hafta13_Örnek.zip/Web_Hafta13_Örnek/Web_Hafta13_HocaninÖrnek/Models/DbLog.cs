﻿namespace Web_Hafta13_HocaninÖrnek.Models
{
    public class DbLog:ILog
    {
        public void LogYaz()
        {
            Console.WriteLine("Veri tabanına dosyasına log yazıldı");
        }
    }
}
