﻿namespace Web_Hafta13_HocaninÖrnek.Models
{
    public class ConsoleLog : ILog
    {
        public int ClassId { get; set; }
        public ConsoleLog()
        {
            Random rnd = new Random();
            ClassId = rnd.Next(1,100);
        }
        public void LogYaz()
        {
            Console.WriteLine($"Console dosyasına log yazıldı ClassId={ClassId}");
        }
    }
}
