﻿namespace Web_Hafta13_HocaninÖrnek.Models
{
    public class TextLog:ILog
    {
        public void LogYaz()
        {
            Console.WriteLine("Text dosyasına log yazıldı");
        }
    }
}
