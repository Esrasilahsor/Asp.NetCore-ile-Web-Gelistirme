﻿namespace Web_Hafta13_HocaninÖrnek.Models
{
    public interface ILog
    {
        public void LogYaz();
    }
}
