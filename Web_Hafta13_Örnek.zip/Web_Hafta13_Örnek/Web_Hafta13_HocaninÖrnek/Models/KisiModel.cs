﻿using System.Diagnostics;
using Web_Hafta13_HocaninÖrnek.Services;


namespace Web_Hafta13_HocaninÖrnek.Models
{
    public class KisiModel
    {
        public string Id { get; set; }
        public string TCNo { get; set; }
        public string AdSoyad { get; set; }

        public MernisService _srv;
        public KisiModel(MernisService srv, string TCNo)
        {
            _srv = srv;
            this.TCNo = TCNo;
        }

        public void KisiBilgileriniYukle()
        {
            this.AdSoyad = _srv.KisiGetir(TCNo);
        }
    }
}
