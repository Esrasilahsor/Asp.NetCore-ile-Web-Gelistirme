﻿using System.Runtime.CompilerServices;
using Web_Hafta12_Middleware.Middlewares;

namespace Web_Hafta12_Middleware.Extensions
{
    static public class Extension
    {
        public static IApplicationBuilder UseHello(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<HelloMiddleware>();
        }
    }
}
