using Web_Hafta12_Middleware.Extensions;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();
app.MapControllerRoute("main","{controller=Home}/{action=Index}/{id?}");

//app.Use(async (context, next) =>
//{
//    Console.WriteLine("Start Use Middleware 1");
//    await next.Invoke();
//    Console.WriteLine("Stop Use Middleware 1");
//});

//app.Use(async (context, next) =>
//{
//    Console.WriteLine("Start Use Middleware 2");
//    await next.Invoke();
//    Console.WriteLine("Stop Use Middleware 2");
//});
//app.Use(async (context, next) =>
//{
//    Console.WriteLine("Start Use Middleware 3");
//    await next.Invoke();
//    Console.WriteLine("Stop Use Middleware 3");
//});

app.UseHello();

app.Run(async context =>
{
    Console.WriteLine("Run middleware");
});

app.Run();