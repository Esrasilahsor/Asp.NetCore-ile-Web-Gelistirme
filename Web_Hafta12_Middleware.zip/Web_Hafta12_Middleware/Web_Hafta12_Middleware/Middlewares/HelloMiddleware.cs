﻿using System.Threading.Tasks;

namespace Web_Hafta12_Middleware.Middlewares
{
    public class HelloMiddleware
    {
        RequestDelegate _next;
        public HelloMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke (HttpContext httpContext)
        {
            Console.WriteLine("Selamun aleyküm");
            await _next.Invoke(httpContext);
            Console.WriteLine("Aleyküm selam");
        }
    }
}
