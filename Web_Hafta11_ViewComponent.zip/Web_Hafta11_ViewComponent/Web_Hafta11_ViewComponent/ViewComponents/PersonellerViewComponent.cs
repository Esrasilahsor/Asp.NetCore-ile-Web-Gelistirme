﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta11_ViewComponent.Models;

namespace Web_Hafta11_ViewComponent.ViewComponents
{
    public class PersonellerViewComponent :ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            List<Personel> datas = new List<Personel>
            {
                new Personel {Adi="Ercan",Soyadi="Silahşor"},
                new Personel {Adi="Ayşe",Soyadi="Silahşor"},
                new Personel {Adi="Sultan",Soyadi="Silahşor"},
                new Personel {Adi="Esra",Soyadi="Silahşor"},
                new Personel {Adi="Cennet",Soyadi="Silahşor"}

            };
            return View(datas);
        }
    }
}
