﻿namespace Web_Hafta11_ViewComponent.Models
{
    public class Personel
    {
        public string Adi { get; set; }
        public string Soyadi { get; set; }
    }
}
