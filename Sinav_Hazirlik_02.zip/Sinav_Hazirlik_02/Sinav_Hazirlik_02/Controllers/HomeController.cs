﻿using Microsoft.AspNetCore.Mvc;
using Sinav_Hazirlik_02.Models;

namespace Sinav_Hazirlik_02.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var urun = new List<Urun>
            {
                new Urun{Id=1,Name="Ürün 1",Description="Bu ürün bir makarnadır."},
                new Urun{Id=2,Name="Ürün 2",Description="Bu ürün bir içecektir."},
                new Urun{Id=3,Name="Ürün 3",Description="Bu ürün bir tahıldır."}

            };

            return View(urun);
        }
    }
}
