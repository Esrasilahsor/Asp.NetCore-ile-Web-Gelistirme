﻿namespace Sinav_Hazirlik_02.Models
{
    public class Urun
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

    }
}
