﻿using Microsoft.AspNetCore.Mvc;

namespace Web_Hafta9_Validations.Controllers
{
    public class AnaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
