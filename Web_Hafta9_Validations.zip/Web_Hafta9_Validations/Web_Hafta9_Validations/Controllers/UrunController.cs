﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta9_Validations.Models;

namespace Web_Hafta9_Validations.Controllers
{
    public class UrunController : Controller
    {
        public IActionResult UrunleriGetir()
        {
            return View();
        }
        public IActionResult UrunOlustur()
        {
            ViewBag.Message = "";
            Urun u =new Urun();
            return View(u);
        }
        [HttpPost]
        public IActionResult UrunOlustur(Urun model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Message = "Kullanıcı eklendi";
            }
            else
            {
                ViewBag.Message = "Kullanıcı eklenirken hata oluştu";
            }


                return View(model);
        }
    }
}
