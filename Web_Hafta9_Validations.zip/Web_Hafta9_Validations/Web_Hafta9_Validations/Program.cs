using FluentValidation;
using FluentValidation.AspNetCore;
using Web_Hafta9_Validations.Models.Validators;


var builder = WebApplication.CreateBuilder(args);


builder.Services.AddValidatorsFromAssemblyContaining<UrunValidator>();
// builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddFluentValidationClientsideAdapters();


builder.Services.AddControllersWithViews();
    

var app = builder.Build();

app.UseStaticFiles(new StaticFileOptions()
{
    RequestPath = "/wwwroot",
});


app.MapControllerRoute("main","{controller=Ana}/{action=Index}/{id?}");

app.Run();
