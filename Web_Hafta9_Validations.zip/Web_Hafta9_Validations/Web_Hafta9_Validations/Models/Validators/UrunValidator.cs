﻿using FluentValidation;

namespace Web_Hafta9_Validations.Models.Validators
{
    public class UrunValidator: AbstractValidator<Urun>
    {
        public UrunValidator():base()
        {
            RuleFor(a => a.UrunAdi).NotNull().WithMessage("Bu alan boş bırakılamaz")
                .NotEmpty().WithMessage("Bu alan boş bırakılamaz")
                .MinimumLength(5).WithMessage("Minimum 5 karakter olmalı")
                .MaximumLength(15).WithMessage("Maximum 15 karakter olmalı")
                ;
            RuleFor(a => a.Email)
                .NotNull().WithMessage("Bu alan boş bırakılamaz")
                .NotEmpty().WithMessage("Bu alan boş bırakılamaz")
                .EmailAddress().WithMessage("Geçerli bir email adresi giriniz")
                .MinimumLength(5).WithMessage("Minimum 5 karakter olmalı")
                .MaximumLength(15).WithMessage("Maximum 15 karakter olmalı")
                ;
        }
    }
}
