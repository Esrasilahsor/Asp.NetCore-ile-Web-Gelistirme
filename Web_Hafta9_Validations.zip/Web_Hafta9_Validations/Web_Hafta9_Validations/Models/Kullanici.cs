﻿namespace Web_Hafta9_Validations.Models
{
    public class Kullanici
    {
    }
}
