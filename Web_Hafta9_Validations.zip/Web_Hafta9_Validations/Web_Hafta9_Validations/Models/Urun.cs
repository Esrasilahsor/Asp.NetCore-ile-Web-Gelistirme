﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Web_Hafta9_Validations.Models
{
    [ModelMetadataType(typeof(UrunMetadata))]
    public class Urun
    {
        
        public string UrunAdi { get; set; }
        public int? Fiyat { get; set; }
        public string Email { get; set; }
        public Urun()
        {

        }

        public Urun(string urunAdi, int? fiyat, string email)
        {
            UrunAdi = urunAdi;
            Fiyat = fiyat;
            Email = email;
        }
    }
    
}
