﻿using System.ComponentModel.DataAnnotations;

namespace Web_Hafta9_Validations.Models
{
    public class UrunMetadata
    {
        //[Required(ErrorMessage = "Lütfen ürün adını giriniz")]
        //[StringLength(100, ErrorMessage = "Lütfen Ürün adını en fazla 100 karakter giriniz")]
        //public string UrunAdi { get; set; }
        //[Required(ErrorMessage = "Lütfen email giriniz")]
        //[EmailAddress(ErrorMessage = "Lütfen doğru bir email adresi giriniz")]
        //public string Email { get; set; }
    }
}
