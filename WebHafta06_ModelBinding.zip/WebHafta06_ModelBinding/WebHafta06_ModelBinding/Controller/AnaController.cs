﻿using Microsoft.AspNetCore.Mvc;
using WebHafta06_ModelBinding.Models;

namespace WebHafta06_ModelBinding.Controllers
{
    public class AnaController : Controller
    {
        static List<Urun> _UrunListe = new List<Urun>()
        {
            new Urun(1, "29' Monitör", 49999.99),
            new Urun(2,"16gb RAM",24999.99),
            new Urun(3,"i9-13900h İşlemci",69999.99),
            new Urun(4,"Kablosuz Klavye",19999.99),
            new Urun(5,"Kablosuz Mouse",9999.99)
        };
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Listele()
        {
            return View(_UrunListe);
        }

        public IActionResult Ekle()
        {
            Urun urun =new Urun();
            return View(urun);
        }
        [HttpPost]
        public IActionResult Ekle(Urun urun)
        {
            _UrunListe.Add(urun);
            return View(urun);
        }
        public IActionResult Duzenle(int id)
        {
            Urun? duzenlenecekUrun = _UrunListe.FirstOrDefault(urun => urun.UrunId == id);
            return View(duzenlenecekUrun);
        }
        [HttpPost]
        public IActionResult Duzenle(Urun urun)
        {
            Urun? duzenlenenUrun= _UrunListe.FirstOrDefault(a => a.UrunId == urun.UrunId);
            duzenlenenUrun.UrunId=urun.UrunId;
            duzenlenenUrun.UrunAdi=urun.UrunAdi;
            duzenlenenUrun.UrunFiyat=urun.UrunFiyat;
            return View(duzenlenenUrun);
        }

        public IActionResult Sil(int id)
        {
            Urun silinecekUrun = _UrunListe.FirstOrDefault(a => a.UrunId==id);
            _UrunListe.Remove(silinecekUrun);
            return RedirectToAction("Listele");
        }
       
    }
}
