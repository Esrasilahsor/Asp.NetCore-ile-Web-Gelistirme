﻿namespace WebHafta06_ModelBinding.Models
{
    public class Urun
    {
        public int UrunId { get; set; }
        public string UrunAdi { get; set; }
        public double UrunFiyat { get; set; }


        public Urun()
        {

        }

        public Urun(int id, string adi, double fiyat)
        {
            this.UrunId = id;
            this.UrunAdi = adi;
            this.UrunFiyat = fiyat;
        }
    }
}
