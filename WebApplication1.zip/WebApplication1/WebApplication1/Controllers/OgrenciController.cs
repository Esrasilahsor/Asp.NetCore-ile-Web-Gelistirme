﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class OgrenciController : Controller
    {
 
        public IActionResult Index()
        {
            {

            }
            return View();
        }
        public IActionResult Listele()
        {
            return View();
        }


    }
}
