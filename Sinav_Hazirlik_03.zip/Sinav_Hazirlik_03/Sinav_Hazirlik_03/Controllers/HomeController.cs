﻿using Microsoft.AspNetCore.Mvc;

namespace Sinav_Hazirlik_03.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
