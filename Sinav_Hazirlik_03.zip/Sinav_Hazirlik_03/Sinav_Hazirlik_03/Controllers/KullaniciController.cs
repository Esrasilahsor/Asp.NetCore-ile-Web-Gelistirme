﻿using Microsoft.AspNetCore.Mvc;
using Sinav_Hazirlik_03.Models;

namespace Sinav_Hazirlik_03.Controllers
{
    public class KullaniciController : Controller
    {
        public IActionResult Kullanici()
        {
            Kullanici k = new Kullanici();

            k.KullaniciId = 1;
            k.KullaniciAdi = "Esra";
            k.KullaniciEmail = "esrasilahsor@ogr.bandirma.edu.tr";
            k.KullaniciSifre = "12345";

            ViewBag.k = k;
            return View();
        }
    }
}
