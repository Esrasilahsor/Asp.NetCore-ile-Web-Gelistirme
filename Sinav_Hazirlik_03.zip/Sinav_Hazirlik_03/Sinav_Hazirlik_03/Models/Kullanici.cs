﻿namespace Sinav_Hazirlik_03.Models
{
    public class Kullanici
    {
        public int KullaniciId { get; set; }
        public string KullaniciAdi { get; set; }
        public string KullaniciEmail{ get; set; }
        public string KullaniciSifre { get; set; }

    }
}
