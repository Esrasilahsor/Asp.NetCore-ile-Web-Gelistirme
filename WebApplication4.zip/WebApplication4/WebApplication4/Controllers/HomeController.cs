using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Dersler()
        {
            return View();
        }
        public IActionResult Ogrenciler()
        {
            return View();
        }
        public IActionResult Gizlilik()
        {
            return View();
        }


    }
}
