using FluentValidation;
using FluentValidation.AspNetCore;
using Web_Hafta10_11_�rnek.Extensions;
using Web_Hafta10_11_�rnek.Models.Validators;
using Web_Hafta10_11_�rnek.Models;


var builder = WebApplication.CreateBuilder(args);

builder.Services.AddValidatorsFromAssemblyContaining<KullaniciValidator>();
//builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddFluentValidationClientsideAdapters();

builder.Services.AddControllersWithViews();

builder.Services.AddTransient<ILog, ConsoleLog>();

var app= builder.Build();

app.UseStaticFiles(new StaticFileOptions()
    {
        RequestPath="/wwwroot",
    });


app.MapControllerRoute("yonetim","yonetim/{action=Index}/{id?}");
app.MapControllerRoute("main","{controller=Home}/{action=Index}/{id?}");

app.UseEsra();

app.Run();