﻿namespace Web_Hafta10_11_Örnek.DependecyInjection
{
    public interface ITopluTasima
    {
        public void BiletBas();
    }
}
