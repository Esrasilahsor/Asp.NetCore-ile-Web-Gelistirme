﻿namespace Web_Hafta10_11_Örnek.DependecyInjection
{
    public class Otobus:ITopluTasima
    {
        public void BiletBas()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Bilet basıldı...");
        }
    }
}
