﻿namespace Web_Hafta10_11_Örnek.DependecyInjection
{
    public class Metrobus:ITopluTasima
    {
        public void BiletBas()
        {
            throw new NotImplementedException();
        }
    }
}
