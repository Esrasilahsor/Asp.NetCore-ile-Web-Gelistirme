﻿namespace Web_Hafta10_11_Örnek.DependecyInjection
{
    public class Metro: ITopluTasima
    {
        public void BiletBas()
        {
            throw new NotImplementedException();
        }
    }
}
