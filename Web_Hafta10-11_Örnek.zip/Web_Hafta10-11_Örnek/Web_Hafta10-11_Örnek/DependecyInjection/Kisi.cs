﻿namespace Web_Hafta10_11_Örnek.DependecyInjection
{
    public class Kisi
    {
        ITopluTasima _ıtt;
        public Kisi(ITopluTasima ıtt)
        {
            _ıtt = ıtt;
        }
    }
}
