﻿using System.Threading.Tasks;

namespace Web_Hafta10_11_Örnek.Middlewares
{
    public class EsraMiddleware
    {
        RequestDelegate _next;
        public EsraMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpcontext)
        {
            Console.WriteLine("Esra");
            await _next.Invoke(httpcontext);
            Console.WriteLine("Silahşor");
        }
    }
}
