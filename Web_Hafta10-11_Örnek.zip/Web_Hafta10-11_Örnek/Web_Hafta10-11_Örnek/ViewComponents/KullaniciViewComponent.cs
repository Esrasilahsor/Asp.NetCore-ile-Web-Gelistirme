﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta10_11_Örnek.Models;

namespace Web_Hafta10_11_Örnek.ViewComponents
{
    public class KullaniciViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            List<Kullanici> kul = new List<Kullanici>()
            {
                new Kullanici{KullaniciId = 1, KullaniciAd="Esra",KullaniciEmail="esrasilahsor16@gmail.com", KullaniciSifre="12345"}
            };
            return View(kul);
        }
    }
}
