﻿namespace Web_Hafta10_11_Örnek.Models
{
    public class TextLog:ILog
    {
        public void LogYaz()
        {
            Console.WriteLine("Text dosyasına log yazıldı...");
        }
    }
}
