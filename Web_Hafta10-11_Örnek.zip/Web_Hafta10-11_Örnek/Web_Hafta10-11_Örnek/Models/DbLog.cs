﻿namespace Web_Hafta10_11_Örnek.Models
{
    public class DbLog:ILog
    {
        public void LogYaz()
        {
            Console.WriteLine("Veri tabanına log yazıldı");
        }
    }
}
