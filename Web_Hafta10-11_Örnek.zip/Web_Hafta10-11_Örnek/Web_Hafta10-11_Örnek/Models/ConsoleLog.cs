﻿namespace Web_Hafta10_11_Örnek.Models
{
    public class ConsoleLog:ILog
    {
        public int ClassId {  get; set; }
        public ConsoleLog()
        {
            Random rnd = new Random();
            ClassId=rnd.Next(1,100);
        }
        
        public void LogYaz()
        {
            Console.WriteLine($"Console log yazıldı... ClassId={ClassId}");
        }
    }
}
