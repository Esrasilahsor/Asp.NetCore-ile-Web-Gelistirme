﻿namespace Web_Hafta10_11_Örnek.Models
{
    public interface ILog
    {
        public void LogYaz();
    }
}
