﻿using FluentValidation;
namespace Web_Hafta10_11_Örnek.Models.Validators
{
    public class KullaniciValidator: AbstractValidator<Kullanici>
    {
        public KullaniciValidator():base()
        {
            RuleFor(a => a.KullaniciAd)
                .NotNull().WithMessage("Bu alan boş bırakılamaz")
                .NotEmpty().WithMessage("Bu alan boş bırakılamaz")
                .MinimumLength(5).WithMessage("Minimum 5 karakter giriniz")
                .MaximumLength(20).WithMessage("Maximum 20 karakter giriniz")
                ;
            RuleFor(a => a.KullaniciEmail)
                .NotNull().WithMessage("Bu alan boş bırakılamaz")
                .NotEmpty().WithMessage("Bu alan boş bırakılamaz")
                .EmailAddress().WithMessage("Lütfen geçerli bir mail adresi giriniz")
                ;
            RuleFor(a => a.KullaniciSifre)
                .NotNull().WithMessage("Bu alan boş bırakılamaz")
                .NotEmpty().WithMessage("Bu alan boş bırakılamaz")
                .MinimumLength(8).WithMessage("Sifre en az 8 karakter olmalı")
                ;

        }
    }
}
