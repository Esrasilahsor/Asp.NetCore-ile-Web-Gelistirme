﻿namespace Web_Hafta10_11_Örnek.Models
{
    public class Kullanici
    {
        public int? KullaniciId { get; set; }
        public string KullaniciAd { get; set; }
        public string KullaniciEmail { get; set; }
        public string KullaniciSifre { get; set; } 

        public Kullanici()
        {

        }

        public Kullanici(int? id, string ad, string email, string sifre)
        {
            this.KullaniciId = id;
            this.KullaniciAd = ad;
            this.KullaniciEmail = email;
            this.KullaniciSifre= sifre;
        }

    }
}
