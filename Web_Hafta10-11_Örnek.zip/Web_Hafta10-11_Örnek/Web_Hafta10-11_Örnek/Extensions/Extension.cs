﻿using Web_Hafta10_11_Örnek.Middlewares;

namespace Web_Hafta10_11_Örnek.Extensions
{
    static public class Extension
    {
        static public IApplicationBuilder UseEsra(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<EsraMiddleware>();
        }
    }
}
