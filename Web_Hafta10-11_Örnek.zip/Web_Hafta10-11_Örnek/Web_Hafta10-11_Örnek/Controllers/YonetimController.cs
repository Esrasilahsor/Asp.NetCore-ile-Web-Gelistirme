﻿using Microsoft.AspNetCore.Mvc;
using Web_Hafta10_11_Örnek.DependecyInjection;

namespace Web_Hafta10_11_Örnek.Controllers
{
    public class YonetimController : Controller
    {
        [Route("yonetim")]
        public IActionResult Index()
        {
            
            return View();
        }

    }
}
