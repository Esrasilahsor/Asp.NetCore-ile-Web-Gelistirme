using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;
using Web_Hafta10_11_Örnek.DependecyInjection;
using Web_Hafta10_11_Örnek.Models;

namespace Web_Hafta10_11_Örnek.Controllers
{
    public class HomeController : Controller
    {
        ILog _log;
        public HomeController(ILog log)
        {
            this._log = log;
        }
        public IActionResult Index()
        {
            ITopluTasima ıtt1 = new Otobus();
            ITopluTasima ıtt2 = new Metrobus();
            ITopluTasima ıtt3 = new Metrobus();

            ıtt1.BiletBas();

            _log.LogYaz();
            return View();
        }
        public IActionResult Ekle()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Ekle(Kullanici model)
        {
            if(ModelState.IsValid)
            {
                ViewBag.Message = "Kullanıcı eklendi";
            }
            else
            {
                ViewBag.Message = "Kullanıcı eklenirken hata oluştu";
            }
                return View(model);
        }
        public IActionResult Hakkimizda()
        {
            return View();
        }
        public IActionResult Iletisim()
        {
            return View();
        }
        public IActionResult Blog()
        {
            return View();
        }
        public IActionResult Personel()
        {
            return View();
        }

    }
}