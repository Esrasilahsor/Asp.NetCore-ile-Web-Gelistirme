﻿namespace Web_Hafta10_11_Örnek.Services
{
    public class MernisService
    {
        public MernisService()
        {
            throw new Exception("Servise şu an ulaşılamıyor.");
        }
    }
}
